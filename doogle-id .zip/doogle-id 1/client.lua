-- Client for doogle-id
local function openUI()
  SetNuiFocus(true, true)
  SendNUIMessage({ action = 'open' })
end

RegisterCommand('makeid', function()
  openUI()
end)

RegisterNetEvent('doogle-id:client:OpenCreateUI')
AddEventHandler('doogle-id:client:OpenCreateUI', openUI)

RegisterNUICallback('close', function(_, cb)
  SetNuiFocus(false, false)
  cb({ ok = true })
end)

RegisterNUICallback('create', function(data, cb)
  SetNuiFocus(false, false)
  -- data contains: name,dob,job,photo (base64 or url),idnumber,issued
  TriggerServerEvent('doogle-id:server:CreateID', data)
  cb({ ok = true })
end)

RegisterNetEvent('doogle-id:client:ShowID')
AddEventHandler('doogle-id:client:ShowID', function(imageData)
  SetNuiFocus(true, true)
  SendNUIMessage({ action = 'view', image = imageData })
end)


-- NPC interaction: spawn an NPC and allow players to press E to open the create-ID UI
local npc = nil

local function draw3DText(x, y, z, text)
  if type(World3dToScreen2d) == 'function' then
    local ok, onScreen, _x, _y = pcall(function() return World3dToScreen2d(x, y, z) end)
    if ok and onScreen then
      local success = pcall(function()
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextEntry('STRING')
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
      end)
      if success then return end
    end
  end

  -- Fallback 1: use help text (top-left / UI help) if available
  if type(BeginTextCommandDisplayHelp) == 'function' and type(AddTextComponentSubstringPlayerName) == 'function' and type(EndTextCommandDisplayHelp) == 'function' then
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0, 0, 1, -1)
    return
  end

  -- Final fallback: print to server/client console so the prompt isn't lost entirely
  print('[doogle-id] '..tostring(text))
end

Citizen.CreateThread(function()
  if not Config or not Config.NPC or Config.NPC.enabled ~= true then return end

  local npcModelName = Config.NPC.model or 'gc_lemoynecaptive_males_01'
  -- Support multiple coord formats: table with x/y/z, or array {x,y,z[,heading]} (vec2/vec3/vec4)
  local cfgCoords = Config.NPC.coords
  local npcCoords = nil
  local npcHeading = Config.NPC.heading or 0.0
  if type(cfgCoords) == 'table' then
    if cfgCoords[1] and cfgCoords[2] and cfgCoords[3] then
      npcCoords = vector3(tonumber(cfgCoords[1]), tonumber(cfgCoords[2]), tonumber(cfgCoords[3]))
      if cfgCoords[4] then npcHeading = tonumber(cfgCoords[4]) end
    elseif cfgCoords.x and cfgCoords.y and cfgCoords.z then
      npcCoords = vector3(cfgCoords.x, cfgCoords.y, cfgCoords.z)
    end
  end
  if not npcCoords then
    npcCoords = vector3(0.0, 0.0, 0.0)
  end
  local drawDist = Config.NPC.drawDistance or 8.0
  local interactDist = Config.NPC.interactionDistance or 2.5
  local interactKey = Config.NPC.interactKey or 38
  local modifierKey = Config.NPC.modifierKey or 19
  local requireModifier = Config.NPC.requireModifier == true

  print(('doogle-id: attempting to spawn NPC model=%s at x=%.2f y=%.2f z=%.2f heading=%.2f'):format(tostring(npcModelName), npcCoords.x, npcCoords.y, npcCoords.z, npcHeading))
  local model = GetHashKey(npcModelName)
  RequestModel(model)
  local tick = 0
  while not HasModelLoaded(model) and tick < 1000 do
    Wait(10)
    tick = tick + 1
  end
  if HasModelLoaded(model) then
    print('doogle-id: model loaded successfully')

    -- Ensure the player is near the spawn coords before creating the ped (avoid streaming/invisibility issues)
    local px, py, pz = table.unpack(GetEntityCoords(PlayerPedId(), true))
    local playerDist = Vdist(px, py, pz, npcCoords.x, npcCoords.y, npcCoords.z)
    if playerDist > 200.0 then
      print(('doogle-id: player is %.1f away from NPC spawn; waiting to spawn until within 200 units'):format(playerDist))
      while playerDist > 200.0 do
        Wait(1000)
        px, py, pz = table.unpack(GetEntityCoords(PlayerPedId(), true))
        playerDist = Vdist(px, py, pz, npcCoords.x, npcCoords.y, npcCoords.z)
      end
      print('doogle-id: player is now near spawn; proceeding to CreatePed')
    end

    -- Try creating the ped; retry a few times if creation fails (helpful on some servers)
    local created = nil
    for i=1,3 do
      created = CreatePed(model, npcCoords.x, npcCoords.y, npcCoords.z, npcHeading, false, true, true, true)
      print(('doogle-id: CreatePed attempt %d returned %s'):format(i, tostring(created)))
      if created and DoesEntityExist(created) then
        print('doogle-id: CreatePed succeeded')
        npc = created
        break
      end
      Wait(100)
    end
    if npc and DoesEntityExist(npc) then
      SetEntityHeading(npc, npcHeading)
      FreezeEntityPosition(npc, true)
      SetBlockingOfNonTemporaryEvents(npc, true)
      SetEntityInvincible(npc, true)
      -- Make the NPC unkillable, immobile and non-reactive
      SetEntityAsMissionEntity(npc, true, true)
      SetEntityProofs(npc, true, true, true, true, true, true, true, true)
      SetPedCanRagdoll(npc, false)
      SetPedCanRagdollFromPlayerImpact(npc, false)
      SetPedFleeAttributes(npc, 0, 0)
      ClearPedTasksImmediately(npc)
      TaskStandStill(npc, -1)
    end
    SetModelAsNoLongerNeeded(model)
    if not npc or not DoesEntityExist(npc) then
      print('doogle-id: WARNING - NPC was not created successfully. Check model name and that you are streaming the spawn area.')
    end
  else
    print('doogle-id: model failed to load after timeout — NPC will not spawn. Check model name in config.lua')
  end

  while true do
    local sleep = 1000
    if npc and DoesEntityExist(npc) then
      local px, py, pz = table.unpack(GetEntityCoords(PlayerPedId(), true))
      local nx, ny, nz = table.unpack(GetEntityCoords(npc, true))
      local dist = Vdist(px, py, pz, nx, ny, nz)
      if dist < drawDist then
        sleep = 5
        if requireModifier then
          draw3DText(nx, ny, nz + 1.0, "Hold LEFT ALT + Press ~INPUT_CONTEXT~ to create an ID")
          if dist < interactDist and IsControlPressed(0, modifierKey) and IsControlJustReleased(0, interactKey) then
            openUI()
          end
        else
          draw3DText(nx, ny, nz + 1.0, "Press G to create an ID")
          if dist < interactDist and IsControlJustReleased(0, interactKey) then
            openUI()
          end
        end
      end
    end
    Wait(sleep)
  end
end)

AddEventHandler('onResourceStop', function(name)
  if name == GetCurrentResourceName() and npc and DoesEntityExist(npc) then
    DeleteEntity(npc)
  end
end)
