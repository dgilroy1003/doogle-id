-- Config for doogle-id
Config = {}

-- Item name used when adding to inventories. Change to match your inventory's item name.
Config.ItemName = 'doogle_id'

-- Canvas dimensions for generated ID images
Config.Canvas = {
  width = 800,
  height = 500
}

-- Positioning for photo on the ID (x,y,width,height)
Config.PhotoBox = { x = 520, y = 120, w = 220, h = 260 }

-- Default background asset (inside resource html/assets/bg.svg)
Config.Background = 'html/assets/bg.svg'

-- NPC interaction settings: set `enabled = true` to spawn an NPC that opens the ID UI when
-- a player presses the interaction key near it. Model must match a valid ped model for RedM.
Config.NPC = {
  enabled = true,
  model = 'gc_lemoynecaptive_males_01', -- change to a model available on your server
  coords = { x = -175.23, y = 631.79, z = 114.09 },
  heading = 327.00,
  interactionDistance = 2.5,
  drawDistance = 8.0
}

-- Interaction keys for the NPC.
-- Set `interactKey` to 47 to use the G key. No modifier required.
Config.NPC.interactKey = 47 -- G
Config.NPC.modifierKey = 19
Config.NPC.requireModifier = false
